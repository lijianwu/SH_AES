# SH_AES加密
## 简单介绍了下AES的加密、解密使用

包括：

	1.NSData加密

	2.NSString加密

	3.加密、解密的使用

	4.AES加密的补充




